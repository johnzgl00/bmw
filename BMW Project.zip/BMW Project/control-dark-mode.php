
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style-dark.css">
    </head>
    <body>
        <form method="get" action="control-dark-mode.php">
        <div class="flex-container">
            <div class="menu">
                <div class="bmw-btn" onclick="location.href='/index-dark-mode.html'">
                    <img class="bmw-img-s" src="./dark_mode/e36.png">
                </div>

                <div class="btn" onclick=window.location="https://www.spotify.com">
                    <img class="item-img-s-1" src="./dark_mode/spotify.png">
                    <a class="item-txt">Spotify</a>
                </div>
                <div class="btn" onclick=window.location="https://www.soundcloud.com">
                    <img class="item-img-s-2" src="./dark_mode/music.png">
                    <a class="item-txt">Music</a>
                </div>
                <div class="btn">
                    <img class="item-img-s-3" src="./dark_mode/controls-1.png">
                    <a class="item-txt-1">Control</a>
                </div>
                <div class="btn">
                    <img class="item-img-s-4" src="./dark_mode/infocar.png">
                    <a class="item-txt">Infocar</a>
                </div>
                <div class="btn">
                    <img class="item-img-s-5" src="./dark_mode/comfort.png">
                    <a class="item-txt">Comfort</a>
                </div>
                <div class="btn">
                    <img class="item-img-s-6" src="./dark_mode/passen.png">
                    <a class="item-txt">Passen</a>
                </div>

                <div class="btn-full">
                    <img class="item-img-s-7" src="./dark_mode/moon.png">
                    <a class="item-txt">Night Mode</a>
                </div>
                <div class="btn-full">
                    <img class="item-img-s-7" src="./dark_mode/gear.png">
                    <a class="item-txt">Settings</a>
                </div>
            </div>
            <div class="main">
                <div class="first-row">
                    <div class="gauge-full">
                        <img class="item-img-s-7" src="./dark_mode/gas.png">
                        <a class="item-txt">540KM</a>
                    </div>
                    <div class="mode" onclick="location.href='/control-light-mode.html'">
                        <img class="item-img-s-7" src="./dark_mode/dark.png">
                    </div>
                </div>
                <div class="first-row">
                    <div class="gauge-full">
                        <img class="item-img-s-8" src="./dark_mode/light1.png">
                        <a class="item-txt">O Lights</a>
                    </div>
                    <div class="gauge-full">
                        <img class="item-img-s-8" src="./dark_mode/light2.png">
                        <a class="item-txt">I Lights</a>
                    </div>
                    <div class="gauge-full">
                        <input type="color" class="colorBox">
                    </div>

                </div>
                <div class="first-row" style="margin-bottom: 35px;">
                    <div class="gauge-full-2">
                        <img class="item-img-s-8" src="./dark_mode/sound1.png">
                        <input type="range" style="width: 278px; transform: translate(-2px,-2px);">
                        <img class="item-img-s-8" style="margin-left:12px" src="./dark_mode/sound2.png">
                    </div>
                    <div class="mute">
                        <a class="item-txt">Mute</a>
                    </div>
                </div>

                <a class="item-txt" style="color: #ddd; margin:0px 0px 0px 190px;">ACTIVE CONTROL</a>

                <div class="first-row" style="margin-bottom: 104px;">
                    <label class="switch">
                        <input type="checkbox">
                        <span class="slider round"></span>
                    </label>
                    <label class="switch">
                        <input type="checkbox">
                        <span class="slider round"></span>
                    </label>
                    <label class="switch">
                        <input type="checkbox">
                        <span class="slider round"></span>
                    </label>
                    <label class="switch">
                        <input type="checkbox">
                        <span class="slider round"></span>
                    </label>
                </div>
                <div class="last-row">
                    <div class="warning">
                        <a class="item-txt">WARNING</a>
                    </div>
                    <div class="code">
                        <a class="item-txt">CODE</a>
                    </div>
                </div>
            </div>
        </div>
    </form>
    </body>
</html>